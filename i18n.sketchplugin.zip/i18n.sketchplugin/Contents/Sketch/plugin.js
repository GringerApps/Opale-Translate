const Iterator = require("./Iterator");
const { I18nGoParser, ExcelParser } = require("./Parsers");
const AlertWindow = require("./AlertWindow");
const FilePicker = require("./FilePicker")
const Delegator = require("./Delegator");
const Window = require("./Window");
const DropdownButton = require("./DropdownButton");
const { scaleFrame } = require("./viewhelper");
const { TITLE, MESSAGES } = require("./consts");
const ALERT = new AlertWindow(TITLE);

const verifySelection = (context) => {
  const api = context.api();
  const selectedLayers = api.selectedDocument.selectedLayers;
  const selection = new Iterator(selectedLayers);

  if (selection.count() == 0) {
    ALERT.show(MESSAGES.EMPTY_SELECTION);
    return false;
  }

  const artboards = selection.filter((layer) => layer.isArtboard);

  if (artboards.count() != selection.count()) {
    ALERT.show(MESSAGES.WRONG_SELECTION);
    return false;
  }

  return true;
};

const OPTIONS = {
  APPLY_TO: {
    SELECTED_ARTBOARDS: 0
  },
  ADD_ARTBOARD_TO: {
    THE_RIGHT: 0
  },
  CASE_MATCHING: {
    SENSITIVE: 0
  }
};

const BTN_CLICKED = {
  TRANSLATE: 1000,
  CANCEL: 1001
};

translate = (context) => {
  const api = context.api();
  const state = {
    applyTo: OPTIONS.APPLY_TO.SELECTED_ARTBOARDS,
    addNewArtboardTo: OPTIONS.ADD_ARTBOARD_TO.THE_RIGHT,
    caseMatching: OPTIONS.CASE_MATCHING.SENSITIVE,
    firstRowForSuffix: false
  };
  var window = new Window();
  window.setMessageText("Opale");
  window.setInformativeText("Duplicates your artboards and replaces the text in them using the text in a spreadsheet file (.xls, .xlsx or .ods)");

  const fileSelectButton = new FilePickerBtn("Select a spreadsheet");
  fileSelectButton.addToWindow(window);

  const preview = NSView.alloc().initWithFrame(NSMakeRect(0, 0, 480, 180));
  const gridUrl = api.resourceNamed("grid.png");
  const gridSuffixUrl = api.resourceNamed("grid_suffix.png");
  const gridImage = NSImage.alloc().initWithContentsOfURL(gridUrl);
  const gridSuffixImage = NSImage.alloc().initWithContentsOfURL(gridSuffixUrl);
  const imgView = NSImageView.alloc().init();
  imgView.setImage(gridImage);
  imgView.setImageAlignment(2);
  imgView.setImageScaling(0);
  imgView.setTranslatesAutoresizingMaskIntoConstraints(false);

  const NSButtonDelegator = new Delegator({
    callback: () => {
      imgView.setImage(checkBox.state() == NSOnState ? gridSuffixImage : gridImage);
      state.firstRowForSuffix = checkBox.state() == NSOnState;
    }
  });
  const delegator = NSButtonDelegator.getClassInstance();
  const checkBox = NSButton.alloc().init();
  checkBox.setTarget(delegator);
  checkBox.setAction("callback");
  checkBox.setTitle("Use first row for\nartboard suffixes");
  checkBox.setButtonType(NSSwitchButton);
  checkBox.setTranslatesAutoresizingMaskIntoConstraints(false);

  const previewSubviews = {
    img: imgView,
    checkBox
  };
  preview.addSubview(imgView);
  preview.addSubview(checkBox);
  const previewHConstraints = NSLayoutConstraint.constraintsWithVisualFormat_options_metrics_views_("H:|-0-[img(348)]-[checkBox]->=0-|", 0, null, previewSubviews);
  const previewVImgConstraints = NSLayoutConstraint.constraintsWithVisualFormat_options_metrics_views_("V:|-0-[img(180)]->=0-|", 0, null, previewSubviews);
  const previewVCheckBoxConstraints = NSLayoutConstraint.constraintsWithVisualFormat_options_metrics_views_("V:|-7-[checkBox]->=0-|", 0, null, previewSubviews);
  preview.addConstraints(previewHConstraints);
  preview.addConstraints(previewVCheckBoxConstraints);
  preview.addConstraints(previewVImgConstraints);

  window.addAccessoryView(preview);

  const applyToSelector = new DropdownButton()
    .setLabel("Apply to:", DropdownButton.ALIGNMENT.HORIZONTAL, DropdownButton.TEXT_ALIGNMENT.RIGHT)
    .addItems(["Selected artboards"])
    .onSelectionChanged((idx) => {
      state.applyTo = idx;
    })
    .addToWindow(window);

  const newArtboardToSelector = new DropdownButton();
  newArtboardToSelector.setLabel("New artboards to the:", DropdownButton.ALIGNMENT.HORIZONTAL, DropdownButton.TEXT_ALIGNMENT.RIGHT);
  newArtboardToSelector.addItems(["Right"]);
  newArtboardToSelector.onSelectionChanged((idx) => {
    state.addNewArtboardTo = OPTIONS.ADD_ARTBOARD_TO.THE_RIGHT;
  });
  newArtboardToSelector.addToWindow(window);

  const caseMatchingSelector = new DropdownButton();
  caseMatchingSelector.setLabel("Case matching:", DropdownButton.ALIGNMENT.HORIZONTAL, DropdownButton.TEXT_ALIGNMENT.RIGHT);
  caseMatchingSelector.addItems(["Case sensitive"]);
  caseMatchingSelector.onSelectionChanged((a,b) => {
    state.caseMatching = OPTIONS.CASE_MATCHING.SENSITIVE;
  });
  caseMatchingSelector.addToWindow(window);

  window.addButtonWithTitle("Replace text");
  window.addButtonWithTitle("Cancel");

  const btns = window.buttons();
  const replaceBtn = btns[0];
  const ReplaceButtonDelegator = new Delegator({
    callback: () => {
      if(verifySelection(context)) {
        const selectedLayers = api.selectedDocument.selectedLayers;
        const selection = new Iterator(selectedLayers);
        const artboards = selection.filter((layer) => layer.isArtboard);
        const parser = new ExcelParser(state.firstRowForSuffix);
        const fileContent = fileSelectButton.read(parser.encoding);
        const translatedContent = parser.parse(fileContent);
        artboards.forEach((layer) => {
          const frame = layer.frame;
          for (const key in translatedContent) {
            const translations = translatedContent[key];
            const duplicatedLayer = layer.duplicate();
            frame.offset(frame.width + 20, 0);
            duplicatedLayer.frame = frame;
            duplicatedLayer.name = duplicatedLayer.name + "-" + key;
            const iterator = new Iterator([duplicatedLayer]);
            const texts = iterator.filter((layer) => layer.isText, true);
            texts.forEach((layer) => {
              const text = String(layer.text);
              const translation = translations[text] || text;
              layer.text = translation;
            });
          }
        });
      }
    }
  });
  const replaceDelegator = ReplaceButtonDelegator.getClassInstance();
  replaceBtn.setTarget(replaceDelegator);
  replaceBtn.setAction("callback");
  replaceBtn.setHighlighted(true);

  const CancelButtonDelegator = new Delegator({
    callback: () => {
      window.close();
    }
  });
  const cancelDelegator = CancelButtonDelegator.getClassInstance();
  const cancelBtn = btns[1];
  cancelBtn.setTarget(cancelDelegator);
  cancelBtn.setAction("callback");
  cancelBtn.setHighlighted(false);

  const btnClicked = window.runModal();
};

class FilePickerBtn {
  constructor(label){
    const self = this;
    const FILE_PICKER_DELEGATOR = new Delegator({
      "callback": () => self._pickFile()
    });
    const target = FILE_PICKER_DELEGATOR.getClassInstance();
    const btn = NSButton.buttonWithTitle_target_action_("Select file", target, "callback");
    btn.setHighlighted(true);

    this._btn = btn;
    this._label = label || null;
    this._files = [];
  }

  _pickFile() {
    var fp = new FilePicker();
    fp.show();
    this._files = fp.files();
    this._btn.setTitle("Replace file");
    this._btn.setFrameSize(NSMakeSize(200, this._btn.frame().size.height));
    if (this._tf){
      const filename = String(this._files[0]).split('\\').pop().split('/').pop();
      log(filename);
      this._tf.setStringValue('Spreadsheet: ' + filename);
    }
  }

  read(encoding) {
    if (encoding === undefined) {
      encoding = NSUTF8StringEncoding;
    }

    const result = {};
    if (this.files().length < 1) {
      return result;
    }
    const filenames = this.files();
    for (let i = 0; i < filenames.length; i++) {
      const fullpath = filenames[i];

      const content = NSString.alloc().initWithContentsOfFile_encoding_error_(fullpath, encoding, null);
      const filename = fullpath.split('\\').pop().split('/').pop().replace(/\.[^/.]+$/, "");
      result[filename] = content;
    }
    return result;
  }

  files() {
    return this._files;
  }

  addToWindow(window) {
    const btn = this._btn;
    let tf;
    const view = NSView.alloc().initWithFrame(NSMakeRect(0, 0, 400, 30));
    const tfFrame = NSMakeRect(0, 0, 180, 20);

    if (this._label) {
      tf = NSTextField.alloc().initWithFrame(tfFrame);
      this._tf = tf;
      tf.setDrawsBackground(false);
      tf.setEditable(false);
      tf.setBezeled(false);
      tf.setSelectable(true);
      tf.setStringValue(this._label);
    }

    var btnFrame = btn.bounds();

    const btnOrigin = NSMakePoint(
      tfFrame.origin.x + tfFrame.size.width,
      (NSHeight(view.bounds()) - NSHeight(btnFrame)) / 2
    )

    btn.setFrameOrigin(btnOrigin);
    btn.setAutoresizingMask(NSViewMinYMargin | NSViewMaxYMargin);

    if (tf != null) {
      const tfOrigin = NSMakePoint(
        tf.frame().origin.x,
        (NSHeight(view.bounds()) - NSHeight(tf.bounds())) / 2
      );

      tf.setFrameOrigin(tfOrigin);
      tf.setAutoresizingMask(NSViewMinYMargin | NSViewMaxYMargin);

      view.addSubview(tf);
    }

    view.addSubview(btn);

    window.addAccessoryView(view);
  }
}
